// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  // Store the protected account number
  const std::string account_number = "CharlieBrown42";

  // Create a character buffer that can hold up to 19 character plus null terminator
  char user_input[20];

  std::cout << "Enter a value: ";

  // Use setw(20) to limit input size and prevent buffer overflow
  // This ensures the user cannot enter more characters than the buffer safely hold
  std::cin >> std::setw(20) >> user_input;

  // Check if extra characters are still waiting in the input buffer
  // If there are additional characters after 20 inputs,
  // notify the user that too much data was entered
  if (std::cin.peek() != '\n')
  {
	  std::cout << "Error: Too much data was entered." << std::endl;
	  return 1;
  }
  
  // Check whether the user entered too much data
  // If too much input is entered, notify the user and stop the program
  if (std::cin.fail())
  {
	  std::cout << "Error: Too much data was entered." << std::endl;
	  return 1;
  }

  // Display the safe user input
  std::cout << "You entered: " << user_input << std::endl;

  // Display the account number to verify it was not overwritten
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
