// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer 
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}
*/

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0

    // Verify the collection starts empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // Add one value to the collection
    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?

    // Verify the collection is no longer empty
    EXPECT_FALSE(collection->empty());

    // Verify exactly one item was added
    EXPECT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Verify the collection starts empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // Add five values to the collection
    add_entries(5);

    // Verify the collection is no longer empty
    EXPECT_FALSE(collection->empty());
    
    // Verify exactly five values were added
    EXPECT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
    // Verify condition for an empty collection
    EXPECT_GE(collection->max_size(), collection->size());

    // Add 1 entry and verify condition
    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size());

    // Clear collection before next test
    collection->clear();

    // Add 5 entries and verify condition
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());

    // Clear collection before next test
    collection->clear();

    // Add 10 entries and verify condition
    add_entries(10);
    EXPECT_GE(collection->max_size(), collection->size());

}
// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
    // Verify condition for an empty collection
    EXPECT_GE(collection->capacity(), collection->size());

    // Add 1 entry and verify condition
    add_entries(1);
    EXPECT_GE(collection->capacity(), collection->size());

    // Clear collection before next test
    collection->clear();

    // Add 5 entries ad verify condition
    add_entries(5);
    EXPECT_GE(collection->capacity(), collection->size());

    // Clear collection before next test
    collection->clear();

    // Add 10 entries and verify condition
    add_entries(10);
    EXPECT_GE(collection->capacity(), collection->size());
}
// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    // Verify collection starts empty
    ASSERT_EQ(collection->size(), 0);

    // Increase the size of the collection to 10 elements
    collection->resize(10);

    // Verify the collection size increased
    EXPECT_EQ(collection->size(), 10);

    // Verify collection is no longer empty
    EXPECT_FALSE(collection->empty());
}
// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    // Add 10 entries to collection
    add_entries(10);

    // Verify the collection contains 10 elements
    ASSERT_EQ(collection->size(), 10);

    // Reduce the collection size to 5 elements
    collection->resize(5);

    // Verify the collection size dereased
    EXPECT_EQ(collection->size(), 5);

    // Verify the collection is not empty
    EXPECT_FALSE(collection->empty());
}
// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeCollectionToZero)
{
    // Add 10 entries to the collection
    add_entries(10);

    // Verify the collection contains 10 elements
    ASSERT_EQ(collection->size(), 10);

    // Resize the collection to zero elements
    collection->resize(0);

    // Verify the collection size is now zero
    EXPECT_EQ(collection->size(), 0);

    // Verify the collection is empty
    EXPECT_TRUE(collection->empty());
}
// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Add entries to the collection
    add_entries(10);

    // Verify the collection contains data
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 10);

    // Remove all elements from the collection
    collection->clear();

    // Verify the collection is now empty
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}
// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    // Add 10 entries to the collection
    add_entries(10);

    // Verify the collection contains data
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 10);

    // Erase all elements using begin() and end()
    collection->erase(collection->begin(), collection->end());

    // Verify the collection is now empty
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}
// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    // Store the original capacity and size
    auto originalCapacity = collection->capacity();
    auto originalSize = collection->size();

    // Reserve space for 100 elements
    collection->reserve(100);

    // Verify capactiy increased
    EXPECT_GE(collection->capacity(), 100);

    // Verify size did not change
    EXPECT_EQ(collection->size(), originalSize);

    // Verify capacity is greater than or equal to original capacity
    EXPECT_GE(collection->capacity(), originalCapacity);
}
// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexIsInvalid)
{
    // Verify the collection starts empty
    ASSERT_EQ(collection->size(), 0);

    // Negative test:
    // Attempt to access an invalid index and verify the exception is thrown
    EXPECT_THROW(collection->at(0), std::out_of_range);
}
// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
TEST_F(CollectionTest, FrontReturnsFirstElementAfterInsert)
{
    // Add a known value to the collection
    collection->push_back(42);

    // Verify one item exists
    ASSERT_EQ(collection->size(), 1);

    // Verify front() returns the first value inserted
    EXPECT_EQ(collection->front(), 42);
}
TEST_F(CollectionTest, PopBackOnEmptyCollectionRemainsEmpty)
{
    // Verify collection starts empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // Negative test:
    // Do not call pop_back() because it is undefined behavior on an empty vector.
    // Instead verify the collection remains empty and cannot contain elements.
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}